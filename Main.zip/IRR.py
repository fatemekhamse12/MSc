
import pandas as pd
import numpy as np 
import datetime as date 
import math as math 
import matplotlib.pyplot as plt

from scipy.stats import pearsonr
from sklearn.metrics import r2_score 
from sklearn.metrics import mean_squared_error


class model:
     def __init__(self,sw0,cn2,prc,wp,fc,n,c,kh,pet,et0,pro,lai):
          self.sw0=sw0
          self.cn2=cn2
          self.prc=prc
          self.wp=wp
          self.fc=fc
          self.n=n
          self.c=c
          self.kh=kh
          self.pet=pet
          self.et0=et0
          self.pro=pro
          self.lai=lai
class inc(model):
     def __init__(self, sw0, cn2, prc, wp, fc, n, c, kh,pet,et0,pro,lai):
          super().__init__(sw0, cn2, prc, wp, fc, n, c, kh,pet,et0,pro,lai)
     def smax(self):
          return 0.935+0.498*self.lai-0.00575*self.lai**2
     def sv(self):
          return self.smax()*(1-math.exp(-(0.046*self.lai)*(self.prc/self.smax())))
     

class runoff(inc):
     def __init__(self, sw0, cn2, prc, wp, fc, n, c, kh,pet,et0,pro,lai):
          super().__init__(sw0, cn2, prc, wp, fc, n, c, kh,pet,et0,pro,lai)
     
     def sr(self):
          return 25.4*((100/self.cn2)-1)
     def CN1(self): 
             cn1=self.cn2-((20*(100-self.cn2))/(100-self.cn2+math.exp(2.53-.0636*(100-self.cn2))))
             return cn1
     def CN3(self):
        return self.cn2+10*math.exp(.00673*(100-self.cn2))
     def FFC(self):
        return ((self.sw0-self.wp)/(self.fc-self.wp))
     def sr1(self):
        return 25.4*((100/self.CN1())-1)
     def sr2(self):
         return 25.4*((100/self.cn2)-1)
     def sr3(self):
         return 25.4*((100/self.CN3())-1)
     def W1(self):
         return math.log(self.sr3()/(self.sr1()-self.sr3()))+self.W2()
     def W2(self):
           
          return math.log(((0.5*self.sr2()*(self.sr1()-self.sr3()))/(self.sr3()*(self.sr1()-self.sr2())))**2)
     def Sr(self):
     
         return self.sr1()*(1-(self.FFC()/(self.FFC()+math.exp(self.W1()-self.W2()*self.FFC()))))
     def SRP(self):
          if self.prc>0.3*self.Sr():
               return (self.prc-0.3*self.Sr())**2/(self.prc+0.7*self.Sr())
          else:
               return 0
          
     def sw3(self):
         
          return self.sw0+self.prc/(1000*self.n)-self.SRP()/(1000*self.n)-self.sv()/(1000*self.n)
       
  
class DEEP(runoff):
     def __init__(self, sw0, cn2, prc, wp, fc, n, c, kh,pet,et0,pro,lai):
          super().__init__(sw0, cn2, prc, wp, fc, n, c, kh,pet,et0,pro,lai)
     def sw3(self):
          return super().sw3()
     def dp(self):
           if self.sw0>self.fc:
                return self.prc-self.SRP()-(self.fc-self.sw0)*1000*self.n
           else:
                return 0
         
     def sw2(self):
          return self.sw3()-self.dp()/(1000*self.n)
         
class ET(DEEP):
     def __init__(self, sw0, cn2, prc, wp, fc, n, c, kh,pet,et0,pro,lai):
          super().__init__(sw0, cn2, prc, wp, fc, n, c, kh,pet,et0,pro,lai)
     def pro_m(self):
          if self.pet<5:
               # modify soil water depletion based on refrence ET 
               return self.pro+0.04*(5-self.pet)
          else:
               return self.pro
     def sw2(self):
          return super().sw2()

     def RAW(self):
          
          return ((self.pro_m())*(self.fc-self.wp))
     def TAW(self):
          return self.fc-self.wp
     def dr(self):
          return self.fc-self.sw2()
     def ks(self):
          if self.dr()>self.RAW():
               return (self.TAW()-self.dr())/((1-self.pro_m())*self.TAW())
          else:
               return 1 
          
     def ETC(self):
          
          return self.pet*self.ks()
     def sm(self):
          if (self.ETC()/(1000*self.n))<=self.sw2()-self.wp:
                  return self.sw2()-self.ETC()/(1000*self.n)
          if (self.ETC()/(1000*self.n))>self.sw2()-self.wp:
               return self.wp
              
     def evap(self):
          if (self.ETC()/(1000*self.n))<=(self.sw2()-self.wp):
                  return self.ETC()
          if (self.ETC()/(1000*self.n))>(self.sw2()-self.wp):
                 return (self.wp)*self.ETC()
    
     
     def sm2(self):
          return self.sw0+self.prc/(70*self.n)-self.evap()/(70*self.n)-self.SRP()/(70*self.n)-self.sv()/(70*self.n)-self.dp()/(70*self.n)       

          




irr = np.arange(date.datetime(2016,10,1), date.datetime(2017,10,1), date.timedelta(days=1)).astype(date.datetime)
wdata=pd.read_excel('D:\Master\Arizona\Arizona_Irrigation\wdata.xlsx')
wdata=wdata[wdata['DATE'].isin(irr)]
pixel=wdata.PIXEL.unique()
obs=pd.read_excel('D:\Master\Arizona\Arizona_Irrigation\SMAP_AM.xlsx')
time_khasht = np.arange(date.datetime(2016,10,1), date.datetime(2017,3,1), date.timedelta(days=1)).astype(date.datetime)
obs['DATE'] = pd.to_datetime(obs['DATE'])
obs=obs[obs['DATE'].isin(irr)]
planting_obs=obs[obs['DATE'].isin(time_khasht)]
planting_obs=planting_obs.to_numpy()
smaptime=obs.DATE.unique()
obs=obs.to_numpy()
ssm=np.zeros((np.size(obs,0),np.size(obs,1)))
wdata2=wdata[wdata['PIXEL']==2]
rain=wdata2['RAIN'].to_numpy()

kc1=pd.read_excel('D:\Landsat2.xlsx')
kc1=kc1.to_numpy()
kc=(kc1[:,1:]*1.25+0.2)
smap=pd.read_excel('D:\Master\Arizona\Arizona_Irrigation\SMAP_AM_90.xlsx')
smap['DATE'] = pd.to_datetime(smap['DATE'])
col=[]
wdata=wdata[(wdata['DATE']).isin(irr)]
smap=smap[(smap['DATE']).isin(irr)]
for i in smap.columns:
     col.append(i)

col.pop(0)


ssm=np.zeros((np.size(smap,0),np.size(smap,1)-1))
tpot=10
for j in np.arange(np.size(smap,1)-1):
      
      print(j)
      obs_withnan=smap[col[j]].values

      row_notnan=list(np.where(obs_withnan!=90)[0])
      obs22=obs_withnan[row_notnan]
   
      
      if j==np.size(smap,1)-1:
           break
     

      for i in np.arange(np.size(obs_withnan,0)):
           a=0
           b=0
           swi=obs_withnan[1]
           if obs_withnan[i]==90:
                ssm[i,j]=np.nan
           else:
                if i==1:
                     ssm[i,j]=obs_withnan[1]
                     swi_1=swi
                     kt_1=1
                else:
                
                          
                      kt=kt_1/(kt_1+math.exp(-3/tpot))
                      kt_1=kt
                      swi=swi_1+kt*(obs_withnan[i]-swi_1)
                      swi_1=swi
               
                      ssm[i,j]=swi
     

soil_data=pd.read_excel('D:\Master\Arizona\Arizona_Irrigation\soil_result22.xlsx')
df=wdata.to_numpy()
df=np.column_stack((df, np.zeros(np.shape(df)[0])))
df=np.column_stack((df, np.zeros(np.shape(df)[0])))
df=np.column_stack((df, np.zeros(np.shape(df)[0])))
df=np.column_stack((df, np.zeros(np.shape(df)[0])))
df=np.column_stack((df, np.zeros(np.shape(df)[0])))
df=np.column_stack((df, np.zeros(np.shape(df)[0])))
df=np.column_stack((df, np.zeros(np.shape(df)[0])))
df=np.column_stack((df, np.zeros(np.shape(df)[0])))
m=0
lai=pd.read_excel('D:\Master\Arizona\Arizona_Irrigation\LAI.xlsx')
lai=lai.to_numpy()

for i in np.arange(np.size(pixel,0)-1):
      print(i)
    
      wdata2=wdata[wdata['PIXEL']==pixel[i]]
      rain=wdata2['RAIN'].to_numpy()
      et0=wdata2['ET0'].to_numpy()
      #pet=wdata2['PET'].to_numpy()
      row_index=list(np.where(wdata['PIXEL']==pixel[i])[0])
    
 
     
      n=0
      et=[0]
     
      
      wp2=soil_data.loc[i,'wp']
      
      prosity2=soil_data.loc[i,'n']
      
     
      fc2=soil_data.loc[i,'fc']
      
      c=soil_data.loc[i,'c']
      kh=soil_data.loc[i,'kh']
      kh=0.01
      c=2
      pro=soil_data.loc[i,'pro']
      cn=soil_data.loc[i,'cn']
      
     
      run=[0]
      pef=[0]
      cw=[0]
      sm2=[1]
     
      
      sm=[obs[1,i+1]]
      for j in np.arange(np.size(rain,0)):
           if wdata2.loc[row_index[j],'DATE']>date.datetime(2017,3,1) and wp2>0.08:
                wp2=0.08
                n=n+1
                moisture=ET(sm[n-1],cn,rain[j],wp2,fc2,
                prosity2,c,kh
                ,et0[j]*kc[j,i],et0[j],pro,lai[j,i+1])
           else:
                 n=n+1
                 moisture=ET(sm[n-1],cn,rain[j],wp2,fc2,
                 prosity2,c,kh
                ,et0[j]*kc[j,i],et0[j],pro,lai[j,i+1])
          
       
          
           sm.append(moisture.sm())
           sm2.append(moisture.sm2())
          
          
           et.append(moisture.evap())
          
           run.append(moisture.SRP())
         
           cw.append(moisture.dp())
      
      
      sm.pop(0)
      et.pop(0)
      run.pop(0)
      pef.pop(0)
      cw.pop(0)
      sm2.pop(0)
      df[row_index,5]=et
      df[row_index,6]=(sm2)
      df[row_index,4]=run
      df[row_index,7]=cw
      df[row_index,8]=et0
      df[row_index,9]=obs[:,i+1]
      df[row_index,10]=sm
      df[row_index,11]=ssm[:,i]
      

colmn_NAME=['pixel','DATE','sm','ET','rain','RUN','DP','et0','smap','root','smap_root']
data_model=np.column_stack((df[:,3],df[:,2],df[:,6],df[:,5],df[:,1],df[:,4],df[:,7],df[:,8],df[:,9],df[:,10],df[:,11]))
planting=pd.DataFrame(data_model,columns=colmn_NAME)
planting['irr_sm']=0
planting['irr_RS']=0
list1=[104]
for j in np.arange(np.size(pixel,0)-1):
      obs_smap= pd.Series(obs[:,j+1])
      obs_smap=obs_smap.dropna()
      roz_obs=obs[obs_smap.index,0]
      row_index1=list(np.where(planting['pixel']==pixel[j])[0])
      row_index=list(np.where(planting.loc[row_index1,'DATE'].isin(roz_obs))[0])
      n=0
      for i in np.arange((np.size(row_index,0))):
          
          n=n+1
          if n>1:
           
           #print(n)
              a=planting.loc[row_index1[row_index[i]],'smap_root']-planting.loc[row_index1[row_index[i-1]],'smap_root']
              b=planting.loc[row_index1[row_index[i]],'root']-planting.loc[row_index1[row_index[i-1]],'root']
              c=planting.loc[row_index1[row_index[i]],'smap']-planting.loc[row_index1[row_index[i-1]],'smap']
              d=planting.loc[row_index1[row_index[i]],'sm']-planting.loc[row_index1[row_index[i-1]],'sm']
              delta_rain=planting.loc[row_index1[row_index[i]],'rain']
              ta=(planting.loc[row_index[i],'smap_root']-planting.loc[row_index[i-1],'smap_root'])/(planting.loc[row_index[i-1],'smap_root'])
           #irr2.append((a-b)*50)
              if  a>0 and b<=0  and planting.loc[row_index1[row_index[i]],'DATE']>date.datetime(2017,3,1) and delta_rain<1 :
                   planting.loc[row_index1[row_index[i]],'irr_RS']= (a-b)*1000*soil_data.loc[j,'n']
                  #print(a)
              if c>0 and d<=0 and planting.loc[row_index1[row_index[i]],'DATE']>date.datetime(2017,3,1) and delta_rain<1 :
                    planting.loc[row_index1[row_index[i]],'irr_sm']= (c-d)*50*soil_data.loc[j,'n']
                    
          
          
          

def rmse_func(predictions, targets):
    return np.sqrt(((predictions - targets) ** 2).mean())
  
rmse_data=[]
r2_data=[]
r_data=[]
for i in np.arange(np.size(pixel,0)-1):
      if i==19:
           continue
      obs_smap= pd.Series(obs[:,i+1])
      obs_smap=obs_smap.dropna()
      roz_obs=obs[obs_smap.index,0]

      planting_b=planting[planting['pixel']==i]
      planting_b=planting_b[planting_b['DATE'].isin(roz_obs)]
      growing = np.arange(date.datetime(2016,10,1), date.datetime(2017,3,1), date.timedelta(days=1)).astype(date.datetime)
      planting_b=planting_b[planting_b['DATE'].isin(growing)]
      vov=planting_b['smap_root'].to_numpy()
      valid=np.size(vov,0)
      
      rmse=rmse_func(planting_b['smap_root'],planting_b['root'])
      rmse_data.append(rmse)

      es=(planting_b['smap_root']-planting_b['root'])**2
      ssres=np.sum(es)
      tl=(planting_b['smap_root']-np.mean(planting_b['smap_root']))**2
      sstotl=np.sum(tl)
  
   
      r22=r2_score(planting_b['smap_root'],planting_b['root'])
      r2_data.append(r22)
      r=pearsonr(planting_b['root'],planting_b['smap_root'])[0]
      r_data.append(r)

mean_rmse=np.mean(rmse_data) 
mean_r=np.mean(r_data)   
mean_r2=np.mean(r2_data) 
print(f" RMSE MEAN IS {mean_rmse}")
print(f" R MEAN IS {mean_r}")
print(f" R2 MEAN IS {mean_r2}")
fig1 = plt.figure(figsize=(6,3), constrained_layout=True)
gs = fig1.add_gridspec(1, 3)
ax0 = fig1.add_subplot(gs[:, 0])
ax1 = fig1.add_subplot(gs[:, 1])
ax2=fig1.add_subplot(gs[:,2])
ax0.boxplot(r2_data)
ax0.set_ylabel(r'$R^2$')
ax1.boxplot(r_data)
ax1.set_ylabel(r'R')
ax2.boxplot(rmse_data)
ax2.set_ylabel(r'RMSE $\mathrm{[mm^3/mm^3]}$ ')
ax0.set(xticklabels=[])
ax1.set(xticklabels=[])
ax2.set(xticklabels=[])
#plt.savefig('F:\Paper_khamseh\plot\calib2.tiff', format='tiff', dpi=300, bbox_inches='tight')
plt.show()

fig = plt.figure(figsize=(6, 6), constrained_layout=True)
gs = fig.add_gridspec(4,1)
ax0 = fig.add_subplot(gs[0,0])
ax1=fig.add_subplot(gs[2,0])
number=61
string="pixel_61"
obs_smap= pd.Series(obs[:,number+1])
obs_smap=obs_smap.dropna()
roz_obs=obs[obs_smap.index,0]
planting2=planting[planting['pixel']==number]
planting3=planting2[planting2['rain']>3]
rain33=planting3['ET'].to_numpy()
et33=planting3['rain'].to_numpy()

planting2=planting2[planting2['DATE'].isin(roz_obs)].reset_index()
ax0.plot(planting2['DATE'],planting2['root'],label=r'Model',color='r',markersize=20,linestyle="solid")

ax0.plot(planting2['DATE'],planting2['smap_root'],label=r'SMAP',color='c',markersize=30,linestyle='--')
ax0.set_title('Alfalfa Farm',fontsize=12)
ax0.set_ylabel("RZSM (%)" ,fontsize=12)
ax2 = ax0.twinx()
planting22=planting[planting['pixel']==number]
ax2.bar(planting22['DATE'], planting22['rain'], color='k', label='Rainfall')
ax2.set_ylabel('Rainfall (mm)', fontsize=12 )
ax2.tick_params(axis='y')
ax0.grid(True)
ax0.set_ylim(0, 0.3)  # Limits for soil moisture
ax2.set_ylim(planting2['rain'].min(), 30)
fig.tight_layout()
ax0.legend(fontsize=10)
ax2.legend(fontsize=10,loc=2)

open_et=pd.read_excel('D:\Master\Arizona\Arizona_Irrigation\open_et_cotten.xlsx')
ax3=fig.add_subplot(gs[1,0])
planting4=planting[planting['pixel']==number]
planting4['DATE']=pd.to_datetime(planting4['DATE'])
planting4.set_index('DATE',inplace=True)
planting4=planting4.resample('M').sum()
irrigation=open_et[string].to_numpy()-planting4['ET'].to_numpy()
irrigation[0:5]=0

planting2['DATE']=pd.to_datetime(planting2['DATE'])
planting2.set_index('DATE',inplace=True)
planting3=planting2.resample('M').sum()
ax1.grid(True)
ax1.set_ylabel(r"IWU (mm)" ,fontsize=10 )
ax1.plot(planting4.index, irrigation, label=r'IWU$_{ET}$', color='b', alpha=1 ,linestyle='dashdot')
ax1.axvspan(date.datetime(2017,3,1),date.datetime(2017,10,1),alpha=0.2,color='gray')
ax3.plot(planting4.index, planting4['ET'], color='r', alpha=1,label='Model')
ax3.plot(planting4.index, open_et[string], label=r'OpenET', color='g', alpha=1,linestyle="dashdot",markersize=30)
ax3.set_ylabel(' ET (mm)',fontsize=10)
ax3.grid(True)
ax3.legend(fontsize=10,loc=2)
